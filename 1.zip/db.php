<?php
$db = mysqli_connect("localhost", "root", "root", "test4") or die('db connect error');